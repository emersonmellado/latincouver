/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	var _index = __webpack_require__(1);

	var _index2 = _interopRequireDefault(_index);

	var _index3 = __webpack_require__(2);

	var _index4 = _interopRequireDefault(_index3);

	var _index5 = __webpack_require__(3);

	var _index6 = _interopRequireDefault(_index5);

	var _main = __webpack_require__(4);

	var _main2 = _interopRequireDefault(_main);

	var _event = __webpack_require__(5);

	var _event2 = _interopRequireDefault(_event);

	var _splash = __webpack_require__(6);

	var _splash2 = _interopRequireDefault(_splash);

	var _intro = __webpack_require__(7);

	var _intro2 = _interopRequireDefault(_intro);

	var _help = __webpack_require__(8);

	var _help2 = _interopRequireDefault(_help);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	angular.module('latincouver', ['ionic', 'ui.router']).config(_index2.default).config(_index4.default).run(_index6.default).controller('SplashController', _splash2.default).controller('IntroController', _intro2.default).controller('MainController', _main2.default).controller('EventController', _event2.default).controller('HelpController', _help2.default);

/***/ },
/* 1 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	function config($logProvider) {
	  'ngInject';

	  $logProvider.debugEnabled(true);
	}

	exports.default = config;

/***/ },
/* 2 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	function routerConfig($stateProvider, $urlRouterProvider) {
	  'ngInject';

	  $stateProvider.state('intro', {
	    url: '/intro',
	    views: {
	      main: {
	        templateUrl: 'app/locations/intro/intro.html',
	        controller: 'IntroController as introCtrl'
	      }
	    }
	  }).state('splash', {
	    url: '/splash',
	    views: {
	      main: {
	        templateUrl: 'app/locations/splash/splash.html',
	        controller: 'SplashController as splCtrl'
	      }
	    }
	  }).state('main', {
	    url: '/main',
	    views: {
	      main: {
	        templateUrl: 'app/locations/main/main.html',
	        controller: 'MainController as mainCtrl'
	      }
	    }
	  }).state('event', {
	    url: '/event/:eventName',
	    views: {
	      main: {
	        templateUrl: 'app/locations/event/event.html',
	        controller: 'EventController as eventCtrl'
	      }
	    }
	  }).state('help', {
	    url: '/help',
	    views: {
	      help: {
	        templateUrl: 'app/locations/help/help.html',
	        controller: 'HelpController as helpCtrl'
	      }
	    }
	  });

	  $urlRouterProvider.otherwise('/splash');
	}

	exports.default = routerConfig;

/***/ },
/* 3 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	function runBlock($log, $rootScope, $state, $stateParams) {
	  'ngInject';

	  $log.debug('runBlock end');
	  $rootScope.$state = $state;
	  $rootScope.$stateParams = $stateParams;
	}

	runBlock.$inject = ['$log', '$rootScope', '$state', '$stateParams'];
	exports.default = runBlock;

/***/ },
/* 4 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var MainController = function () {
	    function MainController($state) {
	        _classCallCheck(this, MainController);

	        this.$state = $state;
	    }

	    _createClass(MainController, [{
	        key: "toIntro",
	        value: function toIntro() {
	            window.localStorage.didTutorial = "false";
	            console.log("intro");
	            this.$state.go('intro');
	        }
	    }]);

	    return MainController;
	}();

	MainController.$inject = ['$state'];
	exports.default = MainController;

/***/ },
/* 5 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var EventController = function EventController($scope) {
	  'ngInject';

	  _classCallCheck(this, EventController);
	};

	exports.default = EventController;

/***/ },
/* 6 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var SplashController =
	//constructor($scope, $state, $ionicSlideBoxDelegate) {
	function SplashController($state, $timeout, $ionicLoading) {
	    _classCallCheck(this, SplashController);

	    this.$state = $state;
	    this.$timeout = $timeout;
	    // Setup the loader
	    $ionicLoading.show({
	        content: 'Loading',
	        animation: 'fade-in',
	        showBackdrop: true,
	        maxWidth: 200,
	        showDelay: 0
	    });
	    console.log(window.localStorage.didTutorial);
	    if (window.localStorage.didTutorial === "true") {
	        console.log('Skip intro');
	        this.$state.go('main');
	        $ionicLoading.hide();
	    } else {
	        this.$state.go('intro');
	        $ionicLoading.hide();
	    }
	}
	// Set a timeout to clear loader, however you would actually call the $ionicLoading.hide(); method whenever everything is ready or loaded.
	// this.$timeout(() => {
	//     $ionicLoading.hide();
	// }, 500);

	;

	SplashController.$inject = ['$state', '$timeout', '$ionicLoading'];
	exports.default = SplashController;

/***/ },
/* 7 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var IntroController = function () {
	    //constructor($scope, $state, $ionicSlideBoxDelegate) {
	    function IntroController($state) {
	        _classCallCheck(this, IntroController);

	        this.$state = $state;
	        console.log(window.localStorage.didTutorial);
	        if (window.localStorage.didTutorial === "true") {
	            console.log('Skip intro');
	            this.startApp();
	        } else {
	            setTimeout(function () {
	                navigator.splashscreen.hide();
	            }, 750);
	        }
	    }

	    _createClass(IntroController, [{
	        key: "toIntro",
	        value: function toIntro() {
	            window.localStorage.didTutorial = "false";
	            console.log("intro");
	            this.$state.go('intro');
	        }
	    }, {
	        key: "startApp",
	        value: function startApp() {
	            this.$state.go('main');
	            window.localStorage.didTutorial = true;
	        }
	    }]);

	    return IntroController;
	}();

	IntroController.$inject = ['$state'];
	exports.default = IntroController;

/***/ },
/* 8 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var HelpController = function HelpController() {
	  'njInject';

	  _classCallCheck(this, HelpController);
	};

	exports.default = HelpController;

/***/ }
/******/ ]);
angular.module("latincouver").run(["$templateCache", function($templateCache) {$templateCache.put("app/locations/browse/browse.html","<ion-view view-title=\"Browse\" class=\"no-padding\"><ion-content class=\"content no-padding\"><div class=\"list card\"><div ui-sref=\"help\" class=\"item item-image no-padding grow\"><img src=\"assets/images/carnaval_delsol.png\"></div><div class=\"item item-image no-padding grow\"><img src=\"assets/images/expoplaza_latina.png\"></div><div class=\"item item-image no-padding grow\"><img src=\"assets/images/carnaval_delsol.png\"></div><div class=\"item item-image no-padding grow\"><img src=\"assets/images/latin_events_bc.png\"></div></div></ion-content></ion-view>");
$templateCache.put("app/locations/event/event.html","<ion-view class=\"no-padding\" hide-nav-bar=\"true\" view-title=\"Events\"><div class=\"bar bar-header bar-positive\"><button ui-sref=\"main\" class=\"button icon ion-android-arrow-back\"></button><h1 class=\"title\">{{$stateParams.eventName}}</h1></div><ion-content class=\"has-header content no-padding\"><div class=\"item event-buttons-page\"><div class=\"item item-body\"><p>Carnaval de Sol is the biggest Latin festival in the Pacific Northwest. It will be 2 days of live music, art, dance, sports, and poetry in celebration of Latin American Culture. For 2016, Carnaval del Sol will bring together more than 350 artists from different Latin American countries.</p></div><div class=\"row\"><div class=\"col col-50 event-button odd\"><div><i class=\"icon ion-ios-cart-outline icon-button-event\"></i></div><div>TICKETS</div></div><div class=\"col col-50 event-button even\"><div><i class=\"icon ion-ios-list-outline icon-button-event\"></i></div><div>SCHEDULE</div></div></div><div class=\"row\"><div class=\"col col-50 event-button even\"><div><i class=\"icon ion-social-buffer-outline icon-button-event\"></i></div><div>SOCIAL</div></div><div class=\"col col-50 event-button odd\"><div><i class=\"icon ion-ios-paperplane-outline icon-button-event\"></i></div><div>VENUES</div></div></div><div class=\"row\"><div class=\"col col-50 event-button odd\"><div><i class=\"icon ion-ios-cart-outline icon-button-event\"></i></div><div>PHOTO BOOK</div></div><div class=\"col col-50 event-button even\"><div><i class=\"icon ion-ios-list-outline icon-button-event\"></i></div><div>SPONSOR</div></div></div><div class=\"row\"><div class=\"col col-50 event-button even\"><div><i class=\"icon ion-ios-cart-outline icon-button-event\"></i></div><div>INFO</div></div><div class=\"col col-50 event-button odd\"><div><i class=\"icon ion-android-pin icon-button-event\"></i></div><div>MAPS</div></div></div></div></ion-content></ion-view>");
$templateCache.put("app/locations/help/help.html","<ion-view view-title=\"Help\"><ion-content><h1>Help</h1></ion-content></ion-view>");
$templateCache.put("app/locations/intro/intro.html","<ion-view view-title=\"intro\"><button class=\"button button-clear button-skip bottom-right\" ng-click=\"introCtrl.startApp()\">SKIP</button><ion-slides options=\"introCtrl.options\" pager=\"\" slider=\"introCtrl.data.slider\"><ion-slide-page class=\"box first\"><div><h1><span>LATINCOUVER</span> HELPS YOU TO CONNECT AND GROW THROUGH CULTURE AND BUSINESS.</h1></div></ion-slide-page><ion-slide-page class=\"box second\"><div><h1>WE ARE THE SQUARE ONE FOR 100,000 <span>LATIN AMERICANS</span> MAKING BRITISH COLUMBIA THEIR NEW HOME.</h1></div></ion-slide-page><ion-slide-page class=\"box third\"><div><h1>REGARDLESS OF WHERE YOU ARE FROM, <span>LATINCOUVER</span> IS HERE TO HELP BRIDGE THE GAP.</h1><button class=\"button button-full button-energized\" ng-click=\"introCtrl.startApp()\">Start the magic</button></div></ion-slide-page></ion-slides></ion-view>");
$templateCache.put("app/locations/main/main.html","<ion-view view-title=\"main\" class=\"no-padding\"><div class=\"bar bar-header bar-positive bar-positive-main\"><button class=\"button icon ion-android-home\" ng-click=\"mainCtrl.toIntro()\"></button> <img class=\"title-image title-image-main\" align=\"center\" src=\"assets/images/logo-white.png\"></div><ion-content class=\"content no-padding main-content\"><div class=\"list card\"><div ui-sref=\"event({eventName: \'Carnaval del Sol\'})\" class=\"item item-image no-padding grow\"><img src=\"assets/images/carnaval_delsol.png\"></div><div ui-sref=\"event({eventName: \'Expo Plaza Latina\'})\" class=\"item item-image no-padding grow\"><img src=\"assets/images/expoplaza_latina.png\"></div><div ui-sref=\"event({eventName: \'Carnaval del Sol\'})\" class=\"item item-image no-padding grow\"><img src=\"assets/images/carnaval_delsol.png\"></div><div ui-sref=\"event({eventName: \'Latin Events BC\'})\" class=\"item item-image no-padding grow\"><img src=\"assets/images/latin_events_bc.png\"></div></div></ion-content></ion-view>");
$templateCache.put("app/locations/splash/splash.html","<ion-view view-title=\"splash\"><ion-content><img src=\"../assets/images/\" <=\"\" ion-content=\"\"></ion-content></ion-view>");}]);