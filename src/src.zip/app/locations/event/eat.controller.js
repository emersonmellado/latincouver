class EatController {
    constructor() {
    }
}
//EatController.$inject = ['$scope', '$ionicSideMenuDelegate'];
export default EatController;
