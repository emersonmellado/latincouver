class ContestController {
    constructor() {
    }
}
export default ContestController;
